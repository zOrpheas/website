# Water Client reconstructed project

This Fabric Loom project was reconstructed from the supplied decrypted client
classes and loader resources. It targets Minecraft 1.21.11, Yarn
1.21.11+build.4, Fabric Loader 0.18.4, and Java 21.

Build on Windows with:

```powershell
.\gradlew.bat build
```

The remapped Fabric mod is written to `build/libs/`.

## Source layout

- `src/main/java`: all 139 recovered Java source files. Gradle directly
  recompiles 71 source units, including every Mixin class so Loom can generate
  correct runtime mappings.
- `src/recovered/java`: a complete second copy of all 139 recovered source
  files, including the decompiler-damaged units, for continued manual repair.
- `src/main/prebuilt`: normalized named bytecode for 68 source units whose
  decompiled local-variable types are not yet valid Java. Gradle uses these as
  binary fallbacks so the complete mod still builds and remaps successfully.
- `src/main/resources`: the original client assets, metadata, and all 30
  merged mixins.

The exact fallback list is declared in `recoveredBytecodeFallbacks` in
`build.gradle`. Removing a path from that list makes Gradle compile its Java
source, which is useful while repairing classes one by one.

## Validation

`gradlew clean build` completes successfully. The remaining Mixin annotation
processor messages are warnings about shadow lookup, not Java compiler errors.
